import React from "react";

export interface PageHeaderProps {}

const PageHeader = () => {
  return <div>fsfe</div>;
};

export default PageHeader;
